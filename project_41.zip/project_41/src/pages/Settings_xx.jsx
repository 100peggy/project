const Settings_xx = () => {
  return <>Settings_xx page</>;
};

export default Settings_xx;
