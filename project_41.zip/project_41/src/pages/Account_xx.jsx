const Account_xx = () => {
  return <>Account_xx page</>;
};

export default Account_xx;
