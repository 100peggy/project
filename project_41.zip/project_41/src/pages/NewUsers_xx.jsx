const NewUsers_xx = () => {
  return <>Create a new user</>;
};

export default NewUsers_xx;
