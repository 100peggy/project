export { default as Account_xx } from './Account_xx';
export { default as Bookings_xx } from './Bookings_xx';
export { default as Cabins_xx } from './Cabins_xx';
export { default as Dashboard_xx } from './Dashboard_xx';
export { default as Login_xx } from './Login_xx';
export { default as PageNotFound_xx } from './PageNotFound_xx';
export { default as Settings_xx } from './Settings_xx';
export { default as NewUsers_xx } from './NewUsers_xx';
